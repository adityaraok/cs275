%this code has an error since the handlers are in the mat file but the
%graphics works fine
    clf
    shg
    set(gcf,'color','white','name','Gait analysis')
    F = [];
    M = [];
    %load the mat file for the data
    load gaitanalyzers
    V = (F+M)/2;
    X = reshape(V(:,1),15,3);
    L = {[1 5],[5 12],[2 3 4 5 6 7 8],[9 10 11 12 13 14 15]};  % Links
    p = zeros(1,4);
    for k = 1:4
       p(k) = line(X(L{k},1),X(L{k},2),X(L{k},3),'marker','^','markersize',10,'linestyle','-', 'color','red');
    end
    set(p(1),'tag','sad','userdata',zeros(1,3));
    axis([-800 800 -800 800 0 1600])
    lift = get(gca,'position')+[0 .04 0 0];
    set(gca,'xtick',[],'ytick',[], 'ztick',[],'position',lift,'clipping','off')
    view(160,10)

    % to control the gait
    labels = {'speed','stride','sway','bounce','hop'};
    %slider gui
    sliders = zeros(1,5);
    for j = 1:5
       switch j
      case 1
          smin = 1;
          start = 1; 
          smax = 3;
       otherwise
          smin = 0;
          start = 1;
          smax = 3;
       end

        sliders(j) = uicontrol('style','slider','background','white','units','normalized','pos',[.16*j-.13 .07 .14 .03],'min',smin, ...
       'max',smax,'val',start,'sliderstep',[1 2]/(10*smax));
        uicontrol('style','text','string',labels{j},'background','white','units','normalized','position',[.16*j-.12 .02 .10 .04])
    end


period = 151.5751;
omega = 2*pi/period;
fps = 120;    
t = 0;
dt = 2*pi/omega/fps;
while 1
    s = cell2mat(get(sliders,'Value'));
    display(s(2:5));
    %s=[1; 1; 1; 1; 1];
    t = t + s(1)*dt;
    c = [1 sin(omega*t) cos(omega*t) sin(2*omega*t) cos(2*omega*t)]';
    c = [1; s(2:5).*c(2:5)];
    V = (F+M)/2 + 1*(F-M)/2;
    X = reshape(V*c,15,3);
    H = get(p(1),'userdata');
    display(H);
    e = ones(size(H,1),1);
    XH = [X(e,:)+H; X(5,:)];
    set(p(1),'xdata',XH(:,1),'ydata',XH(:,2),'zdata',XH(:,3))
    for k = 2:4
        set(p(k),'xdata',X(L{k},1),'ydata',X(L{k},2),'zdata',X(L{k},3));
    end
    pause(1/(s(1)*fps))
end;
